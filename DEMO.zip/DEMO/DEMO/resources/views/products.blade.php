<!DOCTYPE html>
<html>
<head>
    <title>TamThaiTu</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="{{ asset('../style.css') }}">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="/">TamThaiTu</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="/shirts">Shirt</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pants">Pants</a>
                    <li class="nav-item">
                        <a class="nav-link" href="accessories">Accessories</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="shoes">Shoes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/products">Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About Us</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Welcome to TamThaiTu</h1>
                <p>Check out our latest products:</p>
            </div>
        </div>
        <div class="row">
            
            @foreach($products as $product)
            <form action="{{ route('cart.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="col-md-4">
                    <div class="card mb-4 box-shadow">  
                        <input type="hidden"   id="product_id" name="product_id" value="{{ $product->id }}"required>                   
                        <img class="card-img-top" src="{{ asset('images/' . $product->image) }}">      
                        <input type="hidden" class="form-control" id="image" name="image" value="{{  $product->image }}">
                        <div class="card-body">
                            <h4 class="card-title">{{ $product->name }}<input type="hidden" class="form-control" id="name" value="{{ $product->name }}"  name="name" required></h4>
                            <p class="card-text">{{ $product->description }}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="price">Price: {{ $product->price }}$</span>
                                <input type="hidden" class="form-control" id="price" name="price"  value="{{ $product->price }} "required>
                            </div>
                            <h4 class="card-title"><input type="text" class="form-control" id="quantity"  name="quantity" required></h4>
                            <h4 class="card-title">
                                <select id="size"  name="size">
                                    <option value=''>Choose Size</option>
                                    <option value='L'>L</option>
                                    <option value='XL'>XL</option>
                                    <option value='XXL'>XXL</option>
                                </select>
                                
                            </h4>
                             <button type="submit" class="btn btn-primary">BUY</button>
                        </div>
                    </div>
                </div>
            </form>
            @endforeach
           
        
        </div>

    </div>

    <footer>
        <p>&copy; 2023 TamThaiTu. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>












    