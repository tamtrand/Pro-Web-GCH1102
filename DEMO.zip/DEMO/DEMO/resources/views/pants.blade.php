@extends('homepage')
@section('Pants')
<body>
    <ul>
        @foreach ($products as $product)
            <li>{{ $product->name }} - {{ $product->price }}</li>
        @endforeach
    </ul>
</body>
@endsection