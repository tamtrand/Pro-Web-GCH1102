<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Product;

class HomeController extends Controller
{
    public function index()
    {
        $products = DB::table('products')->take(3)->get();
        return view('homepage', compact('products'));
    }
}