<!DOCTYPE html>
<html>
<head>
    <title>Homepage</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('../style.css')); ?>">
</head>
body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">TamThaiTu</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                              Category
                            </button>
                            <ul class="dropdown-menu">
                              <li><button class="dropdown-item" type="button">Shirt</button></li>
                              <li><button class="dropdown-item" type="button">Pants</button></li>
                            </ul>
                          </div>
                    <li class="nav-item">
                        <a class="nav-link" href="/products">Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Welcome to TamThaiTu</h1>
                <p>Check out our latest products:</p>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-4 box-shadow">
                        <img class="card-img-top" src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e($product->name); ?></h4>
                            <p class="card-text"><?php echo e($product->description); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="price">Price: <?php echo e($product->price); ?></span>
                                <a href="#" class="btn btn-sm btn-outline-secondary">View details</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <footer>
        <p>&copy; 2023 TamThaiTu. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <h1>Products</h1>
    <div class="row">   
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-3">
          <div class="card h-100">
            <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>" class="card-img-top">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($product->name); ?></h5>
              <p class="card-text">$<?php echo e($product->price); ?></p>
              <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-primary">View Details</a>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?><?php /**PATH C:\ASM\Demo\resources\views/products.blade.php ENDPATH**/ ?>