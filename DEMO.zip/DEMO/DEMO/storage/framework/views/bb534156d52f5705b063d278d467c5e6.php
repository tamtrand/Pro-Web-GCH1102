<!DOCTYPE html>
<html>
<head>
    <title>TamThaiTu</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('../style.css')); ?>">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="/">TamThaiTu</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="/shirts">Shirt</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pants">Pants</a>
                    <li class="nav-item">
                        <a class="nav-link" href="accessories">Accessories</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="shoes">Shoes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/products">Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About Us</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Welcome to TamThaiTu</h1>
                <p>Check out our latest products:</p>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $product->image = asset('images/' . $product->image);
            ?>
                <div class="col-md-4">
                    <div class="card mb-4 box-shadow">
                        <img class="card-img-top" src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e($product->name); ?></h4>
                            <p class="card-text"><?php echo e($product->description); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="price">Price: <?php echo e($product->price); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <footer>
        <p>&copy; 2023 TamThaiTu. All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script><?php /**PATH C:\xampp\htdocs\ASM\Demo\resources\views/homepage.blade.php ENDPATH**/ ?>