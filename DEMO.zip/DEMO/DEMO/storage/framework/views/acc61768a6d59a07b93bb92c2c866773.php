
<?php $__env->startSection('admin'); ?>

        <div class="container">
            <h1>Products List</h1>
           
            <table class="table">
                <thead>
                    <tr>
                        
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Images</th>
                        <th>Quantity</th> 
                        <th>Size</th>   
                        <th>Update</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><img class="card-img-top" src="<?php echo e(asset('images/' . $product->image)); ?>" style="max-height:100px;"></td>
                        <form action="<?php echo e(route('cart.edit', $product->id)); ?>" method="POST" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <td><h4 class="card-title"><input type="text" class="form-control" id="quantity"  name="quantity" value="<?php echo e($product->quantity); ?>" required></h4>
                            
                        <td>      <select id="size"  name="size">
                                    <option value='<?php echo e($product->size); ?>'><?php echo e($product->size); ?>(Your Choosen)</option>
                                    <option value='L'>L</option>
                                    <option value='XL'>XL</option>
                                    <option value='XXL'>XXL</option>
                                </select>
                               
                        </td>   
                        <td><button type="submit" class="btn btn-danger" onclick="return confirm('Are You Sure About This Changed')"> Update</button>    </td>
                    </form>  
            
                        <td>
                            
                            <form action="<?php echo e(route('cart.delete', $product->id)); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Do you definitely want to delete this product?')">Delete</button>
                            </form>
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div>
           
            
           
           </div>
        <div>
            <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <button class="px-6 py-2 text-red-800 bg-red-300">Remove All Cart</button>
            </form>
          </div>
          <?php $__env->stopSection(); ?>
         
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DEMO\resources\views/cart.blade.php ENDPATH**/ ?>