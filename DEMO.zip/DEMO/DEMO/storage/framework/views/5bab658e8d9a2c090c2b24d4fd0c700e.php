<!DOCTYPE html>
<html>
<head>
    <title>About Us | TamThaiTu</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('../style.css')); ?>">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="/">TamThaiTu</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                              Category
                            </button>
                            <ul class="dropdown-menu">
                              <li><button class="dropdown-item" href="/product/shirt">Shirt</button></li>
                              <li><button class="dropdown-item" href="/products/pants">Pants</button></li>
                            </ul>
                          </div>
                    <li class="nav-item">
                        <a class="nav-link" href="/products">Product</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="/about">About Us</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>About Us</h1>
                <p>TamThaiTu is a clothing store that offers a wide selection of high-quality clothing for men and women. Our mission is to provide our customers with the best possible shopping experience by offering excellent customer service, a user-friendly website, and fast and reliable shipping.</p>
                <p>Our team of experienced professionals is dedicated to providing our customers with the best possible products and services. We work hard to ensure that our customers are satisfied with their purchases and are always looking for ways to improve our products and services.</p>
                <p>Thank you for choosing TamThaiTu for all of your clothing needs. We look forward to serving you!</p>
            </div>
        </div>
    </div>
    
    <footer>
        <p>&copy; 2023 TamThaiTu. All rights reserved.</p>
    </footer>
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
</body>
</html><?php /**PATH C:\ASM\Demo\resources\views//about.blade.php ENDPATH**/ ?>