<!DOCTYPE html>
<html>
<head>
    <title>Homepage</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <header>
        <div class="logo">
            <a href="#">TamThaiTu</a>
        </div>
        <div class="menu">
            <div class="dropdown">
                <button class="dropbtn">Category</button>
                <div class="dropdown-content">
                    <a href="#">Shirt</a>
                    <a href="#">Pants</a>
                </div>
            </div>
            <a href="#">Product</a>
            <a href="#">About Us</a>
        </div>
    </header>

    <div class="content">
        <h1>Welcome to TamThaiTu</h1>
        <p>Check out our latest products:</p>

        <div class="products">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product">
                    <h3><?php echo e($product->name); ?></h3>
                    <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>">
                    <p><?php echo e($product->description); ?></p>
                    <p>Price: <?php echo e($product->price); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <footer>
        <p>&copy; 2023 TamThaiTu. All rights reserved.</p>
    </footer>
</body>
</html><?php /**PATH C:\ASM\Demo\resources\views/welcome.blade.php ENDPATH**/ ?>