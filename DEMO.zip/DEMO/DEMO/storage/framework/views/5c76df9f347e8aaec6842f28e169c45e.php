<!DOCTYPE html>
<html>
<head>
    <title>About Us | TamThaiTu</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.2/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('../style.css')); ?>">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="/">TamThaiTu</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../shirt">Shirt</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/prodcuts/pants">Pants</a>
                    <li class="nav-item">
                        <a class="nav-link" href="/products">Accessories</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/products">Shoes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/products">Product</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/about">About Us</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>About Us | TamThaiTu</h1>
                <p>Welcome to our store! We are a professional store specializing in luxury clothing, shoes, and accessories. We were founded in 2019 with the contribution of the limited liability company 3anhemIT.</p>
                <p>Our mission is to provide customers with the best and highest quality products from the world's leading brands. With an experienced and dedicated staff, we are committed to providing customers with the best service and ensuring customer satisfaction is our top priority.</p>
                <p>We are not just a simple retail store, but we also bring customers a fun and meaningful shopping experience. With the goal of becoming one of the leading luxury retail brands, we are committed to continuously striving and developing to bring satisfaction to our customers.</p>
                <p>We would like to thank you for visiting our store. Currently, we are still in the process of developing and do not have an online shopping function. We apologize for any inconvenience this may cause and hope you can understand.</p>
                <p>However, we pledge to make every effort to bring our customers the best and highest quality products from the world's leading brands. We are also actively developing online shopping functions and hope to meet the needs of our customers soon.</p>
                <p>Once again, we sincerely thank you for visiting our store. We look forward to seeing you soon at our store.</p>
            </div>
        </div>
    </div>
    
    <footer>
        <p>&copy; 2023 TamThaiTu. All rights reserved.</p>
    </footer>
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\DEMO\DEMO\resources\views/about.blade.php ENDPATH**/ ?>