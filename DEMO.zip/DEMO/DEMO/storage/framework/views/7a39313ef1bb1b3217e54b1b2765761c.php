    

    <?php $__env->startSection('admin'); ?>
        <div class="container">
            <h1>Products List</h1>
            <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-primary mb-3">Thêm sản phẩm</a>
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Images</th>
                        <th>Category</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $product->image = asset('images/' . $product->image);
                    ?>
                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->description); ?></td>
                        <td><?php echo e($product->image); ?></td>
                        <td><?php echo e($product->category->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.edit', $product->id)); ?>" class="btn btn-primary">Edit</a>
                            <form action="<?php echo e(route('admin.delete', $product->id)); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Do you definitely want to delete this product?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ASM\Demo\resources\views/admin/index.blade.php ENDPATH**/ ?>